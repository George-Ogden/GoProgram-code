from turtle import *
import time
color('orange')
speed(0)
bgcolor("black")
ht()
while True:
    for i in range(360):
        for i in range(4):
            forward(225)
            left(90)
        left(1)
    time.sleep(10)
    clear()
        
