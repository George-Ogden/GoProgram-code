from turtle import *
import time
speed(0)
ht()
color("yellow")
pensize(1)
backward(300)
bgcolor("black")
while True:
    for i in range(360):    
        forward(600)
        left(179)
    time.sleep(10)
    clear()
